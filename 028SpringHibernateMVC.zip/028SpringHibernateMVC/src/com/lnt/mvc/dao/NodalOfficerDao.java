package com.lnt.mvc.dao;
import java.util.List;

import com.lnt.mvc.model.FinalApplication;
import com.lnt.mvc.model.ScholarshipApplicationForm;

public interface NodalOfficerDao {

public List<ScholarshipApplicationForm>applications();

public void acceptApplicaton(int studentId);
public void rejectApplication(int studentId);
public ScholarshipApplicationForm  getApplication(int studentId);



}
