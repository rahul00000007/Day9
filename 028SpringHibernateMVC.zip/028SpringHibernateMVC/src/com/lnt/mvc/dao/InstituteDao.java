package com.lnt.mvc.dao;
import java.util.List;

import com.lnt.mvc.model.ScholarshipApplicationForm;
public interface InstituteDao {
	
	
	 
		
	public List<ScholarshipApplicationForm> listapplications();


	public void acceptApplicaton(int studentId);
	public void rejectApplication(int studentId);
	public ScholarshipApplicationForm getApplication(int studentId);

	}

	


