package com.lnt.mvc.dao;

 

 
import java.util.List;

import com.lnt.mvc.model.ScholarshipApplicationForm;
import com.lnt.mvc.model.StudentRegistration;

public interface StudentRegistrationDao {
	
public void save(StudentRegistration s);
public boolean verifyUser(Integer aadharno,String password);
public  boolean verifyMinister(String username,String password);
public boolean verifyOfficer(String officerusername,String officerpassword);
public boolean verifyInstitute(String In_Name,String Password);

//public List<ScholarshipApplicationForm> applicationform();
public void getById(Integer aadharno);
StudentRegistration getStudent(int aadharno, String password);





}
