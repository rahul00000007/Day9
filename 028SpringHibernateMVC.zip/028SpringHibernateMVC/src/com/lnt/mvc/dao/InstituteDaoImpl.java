package com.lnt.mvc.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.mvc.model.FinalApplication;
import com.lnt.mvc.model.ScholarshipApplicationForm;
@Repository
public class InstituteDaoImpl implements InstituteDao {
	
	
	
	@Autowired
	private SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sf) {
	this.sessionFactory = sf;
	}
	private static final Logger logger = 
	LoggerFactory.getLogger(RegistrationDaoImpl.class);


	@Override
	public List<ScholarshipApplicationForm> listapplications() {
	Session session = this.sessionFactory.openSession();

	Transaction tx=session.beginTransaction();

	String query="from ScholarshipApplicationForm";
	Query q=session.createQuery(query);
	List<ScholarshipApplicationForm> applicationList=q.list();

	tx.commit();
	session.close();


	return applicationList;
	 
	}


	@Override
	public void acceptApplicaton(int studentId) {
		
		
		 Session session = this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		String query="update ScholarshipApplicationForm p  set p.institutestatus=1  where p.studentId=:studentId";
		Query q=session.createQuery(query);
		q.setInteger("studentId",studentId);
		q.executeUpdate();
		tx.commit();
		session.close();
		}
		
	

	@Override
	public void rejectApplication(int studentId) {
	Session session = this.sessionFactory.openSession();
	Transaction tx=session.beginTransaction();
	String query="update ScholarshipApplicationForm p set p.institutestatus=0  where p.studentId=:studentId";
	Query q=session.createQuery(query);
	q.setInteger("studentId",studentId);
	q.executeUpdate();
	tx.commit();
	session.close();
	}


	@Override
	public ScholarshipApplicationForm getApplication(int studentId) {
	 
	Session session = this.sessionFactory.openSession();
	Transaction tx=session.beginTransaction();
	String query="from ScholarshipApplicationForm where studentId=:studentId";
	Query q=session.createQuery(query);
	q.setInteger("studentId",studentId);
	List<ScholarshipApplicationForm> applicationList=q.list();
	tx.commit();
	Iterator<ScholarshipApplicationForm> itr= applicationList.iterator();
	ScholarshipApplicationForm scholarshipApplicationForm=new ScholarshipApplicationForm();
	while(itr.hasNext())
	{
	scholarshipApplicationForm= (ScholarshipApplicationForm) itr.next();
	}
	return scholarshipApplicationForm;
	 
	}

	 
	}



