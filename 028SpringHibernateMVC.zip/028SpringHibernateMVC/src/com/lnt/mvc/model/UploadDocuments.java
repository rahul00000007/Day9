package com.lnt.mvc.model;

public class UploadDocuments {

}
