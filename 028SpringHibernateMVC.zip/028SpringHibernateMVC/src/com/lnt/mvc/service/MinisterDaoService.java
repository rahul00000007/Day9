package com.lnt.mvc.service;


import java.util.List;

import com.lnt.mvc.model.FinalApplication1;


public interface MinisterDaoService {
	
	
	public List<FinalApplication1> listapplications();


	public void acceptApplicaton(int studentId);
	public void rejectApplication(int studentId);
	public FinalApplication1 getApplication(int studentId);	
	
	
}

